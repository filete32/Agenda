package ch.makery.address.model;

import ch.makery.address.model.repository.PersonRepository;
import ch.makery.address.model.repository.impl.PersonRepositoryImpl;

import java.util.ArrayList;

public class AgendaModel {

    private PersonRepository personRepository;

    public AgendaModel() {
        this.personRepository = new PersonRepositoryImpl();
    }

    public ArrayList<PersonVO> obtenerListaPersonas() throws ExcepcionPerson {
        return personRepository.ObtenerListaPersonas();
    }
}

