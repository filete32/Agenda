package ch.makery.address.model.repository.impl;

import ch.makery.address.model.ExcepcionPerson;
import ch.makery.address.model.PersonVO;
import ch.makery.address.model.repository.PersonRepository;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class PersonRepositoryImpl implements PersonRepository {

    private final ConexionJDBC conexion = new ConexionJDBC();
    private Statement stmt;
    private String sentencia;
    private ArrayList<PersonVO> people;
    private PersonVO person;

    public PersonRepositoryImpl() {

    }

    public ArrayList<PersonVO> ObtenerListaPersonas() throws ExcepcionPerson {
        try {
            Connection conn = this.conexion.conectarBD();
            this.people = new ArrayList();
            this.stmt = conn.createStatement();
            this.sentencia = "SELECT * FROM Persona";
            ResultSet rs = this.stmt.executeQuery(this.sentencia);

            while(rs.next()) {
                Integer id = rs.getInt("ID");
                String nom = rs.getString("NOMBRE");
                String ape = rs.getString("APELLIDO");
                String calle = rs.getString("CALLE");
                Integer cp = rs.getInt("CP");
                String ciudad = rs.getString("CIUDAD");
                LocalDate cumple = rs.getDate("CUMPLEANO").toLocalDate();
                this.person = new PersonVO(nom,ape,calle,cp,ciudad,cumple);
                this.person.setId(id);
                this.people.add(this.person);
            }

            this.conexion.desconectarBD(conn);
            return this.people;
        } catch (SQLException var6) {
            throw new ExcepcionPerson("No se ha podido realizar la operación");
        }
    }

    public void addPerson(PersonVO m) throws ExcepcionPerson {
        try {
            Connection conn = this.conexion.conectarBD();
            this.stmt = conn.createStatement();
            this.sentencia = "INSERT INTO Persona (NOMBRE, APELLIDO, CALLE, CIUDAD, CUMPLEANO, CP) VALUES ('" + m.getFirstName() +
                    "','" + m.getLastName() + "','" + m.getStreet() + "','" + m.getCity() + "','" + m.getBirthday() +
                    "','" + m.getPostalCode() + "');";
            this.stmt.executeUpdate(this.sentencia);
            this.stmt.close();
            this.conexion.desconectarBD(conn);
        } catch (SQLException var3) {
            System.out.println("$$$" + var3);
            throw new ExcepcionPerson("No se ha podido realizar la operación");
        }
    }

    public void deletePerson(Integer idPersona) throws ExcepcionPerson {
        try {
            Connection conn = this.conexion.conectarBD();
            this.stmt = conn.createStatement();
            Statement comando = conn.createStatement();
            String sql = String.format("DELETE FROM Persona WHERE ID = %d", idPersona);
            comando.executeUpdate(sql);
            this.conexion.desconectarBD(conn);
        } catch (SQLException var5) {
            throw new ExcepcionPerson("No se ha podido realizar la eliminación");
        }
    }

    public void editPerson(PersonVO personVO, Integer id) throws ExcepcionPerson {
        try {
            Connection conn = this.conexion.conectarBD();
            this.stmt = conn.createStatement();
            String sql = String.format("UPDATE Persona SET NOMBRE = '%s', APELLIDO = '%s', CALLE = '%s', CIUDAD = '%s', CUMPLEANO = '%s', CP = '%s' WHERE ID = %d", personVO.getFirstName(), personVO.getLastName(), personVO.getStreet(), personVO.getCity(), personVO.getBirthday(), personVO.getPostalCode(), id);
            this.stmt.executeUpdate(sql);
        } catch (Exception var4) {
            throw new ExcepcionPerson("No se ha podido realizar la edición");
        }
    }

    public int lastId() throws ExcepcionPerson {
        int lastPersonId = 0;

        try {
            Connection conn = this.conexion.conectarBD();
            Statement comando = conn.createStatement();

            for(ResultSet registro = comando.executeQuery("SELECT ID FROM Persona ORDER BY ID DESC LIMIT 1"); registro.next(); lastPersonId = registro.getInt("id")) {
            }

            return lastPersonId;
        } catch (SQLException var5) {
            throw new ExcepcionPerson("No se ha podido realizar la busqueda del ID");
        }
    }

}
