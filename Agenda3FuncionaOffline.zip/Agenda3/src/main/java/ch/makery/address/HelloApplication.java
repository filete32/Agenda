package ch.makery.address;

import ch.makery.address.model.ExcepcionPerson;
import ch.makery.address.model.PersonVO;
import ch.makery.address.model.repository.impl.PersonRepositoryImpl;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Hello!");
        try{
            String dateStr = "24/11/2000";
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate birthDate = LocalDate.parse(dateStr, formatter);
            PersonVO persona6 = new PersonVO("Abraham6","Carrasco6","Afganistan6",410206,"Sevilla6", birthDate);
            PersonVO persona8 = new PersonVO("Abraháñ7","Carrasco7","Afganistan7",410207,"Sevilla7", birthDate);
            PersonVO persona3 = new PersonVO("Javi","Rom","Cuevana",410206,"Sevilla6", birthDate);
            PersonVO persona2 = new PersonVO("Miguelito","Brold","Cuevana3",410206,"Sevilla6", birthDate);
            PersonVO persona1 = new PersonVO("Brlrd","Bard","Loleti",410206,"Sevilla6", birthDate);

            PersonRepositoryImpl rp = new PersonRepositoryImpl();
            //rp.addPerson(persona8);
            //rp.editPerson(persona6,2);
            System.out.println(rp.lastId());

        } catch (ExcepcionPerson e) {
            throw new RuntimeException(e);
        }

        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}